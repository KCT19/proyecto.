<?php
header('location: frontend/login.php');
?>
