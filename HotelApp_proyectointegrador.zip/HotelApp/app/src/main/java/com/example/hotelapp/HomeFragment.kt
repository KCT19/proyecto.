package com.example.hotelapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hotelapp.adapters.Categoria
import com.example.hotelapp.adapters.CategoriaAdapter
import com.example.hotelapp.adapters.Producto
import com.example.hotelapp.adapters.ProductoAdapter

class HomeFragment : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var categoriaAdapter: CategoriaAdapter
    private lateinit var categoriaList: List<Categoria>
    private lateinit var recyclerView2: RecyclerView
    private lateinit var productoAdapter: ProductoAdapter
    private lateinit var productoList: List<Producto>

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflar el diseño del fragmento
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        // Configuración del RecyclerView de categorías en horizontal
        recyclerView = view.findViewById(R.id.recyclerCategorias)
        recyclerView.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)

        // Configuración del RecyclerView de productos en horizontal
        recyclerView2 = view.findViewById(R.id.recyclerProductos)
        recyclerView2.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL    , false)

        // Lista de categorías
        categoriaList = listOf(
            Categoria("Comida y Bebidas", R.drawable.user),
            Categoria("Limpieza de Habitación", R.drawable.user),
            Categoria("Mantenimiento", R.drawable.user),
            Categoria("Servicios Especiales", R.drawable.user)
        )

        // Lista de productos
        productoList = listOf(
            Producto("Pizza Margherita", "Pizza con tomate, queso mozzarella y albahaca.", R.drawable.sauna),
            Producto("Hamburguesa", "Hamburguesa clásica con carne, queso y lechuga.", R.drawable.sauna),
            Producto("Ensalada César", "Ensalada con lechuga, crutones y aderezo César.", R.drawable.sauna),
            Producto("Tacos", "Tacos con carne, guacamole y salsa picante.", R.drawable.sauna)
        )

        // Configuración de los adaptadores
        categoriaAdapter = CategoriaAdapter(categoriaList)
        recyclerView.adapter = categoriaAdapter

        productoAdapter = ProductoAdapter(productoList)
        recyclerView2.adapter = productoAdapter

        return view
    }
}